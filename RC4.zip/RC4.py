def RC4(plaintext, key):
    #initialize
    S = []
    T = []
    if type(key == str):
        key = key.encode()
    #create the arrays S and T with their corresponding values
    for i in range(256): #256 not included
        S.append(i)
        T.append(key[i % len(key)])

    #change the permutation of S
    j = 0
    for i in range(256):
        j = (j + S[i] + T[i]) % 256
        swap(S, i, j)

    #generate as many streams as needed
    #there is a VEEERRYYYYY ANNOYING problem here when the plaintext length is > 7, I couldn't fix it and couldn't find anything to help me fix it
    plaintext = plaintext.encode("UTF-8") #this turns the plaintext into an array of bytes
    i = 0
    j = 0
    ciphertext = ""
    for k in range(len(plaintext) + 1000): #loop for as bytes as plaintext has + 1000 (we will skip the first 1000 bytes)
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        swap(S, i, j)

        if k >= 1000:
            t = (S[i] + S[j]) % 256
            #XOR the byte with the keystream, then turn that ascii value into a character, and add that to the ciphertext
            ciphertext += chr(plaintext[k - 1000] ^ S[t])

    return ciphertext

def swap(arr, i, j):
    k = arr[i]
    arr[i] = arr[j]
    arr[j] = k

print(RC4("hello", "hello, this is a key"))